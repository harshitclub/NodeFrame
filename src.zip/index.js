import NodeFrame from "./src/NodeFrame.js";

const app = new NodeFrame();

app.get("/", (req, res) => {
  res
    .status(200)
    .cookie("NodeFrame", "thisbuiltbyharshitkumar", {
      httpOnly: true,
      secure: true,
      maxAge: 86400000,
      path: "/",
      sameSite: "Strict",
    })
    .json({
      success: true,
      message: "Welcome to NodeFrame!",
      framework: "NodeFrame",
      version: "2.0.0",
    });
});

app.get("/about", (req, res) => {
  res.status(200).send("Welcome to the About Page 🚀");
});

app.get("/profile", (req, res) => {
  res.status(200).json({
    name: "Harshit",
    role: "Backend Developer",
    experience: "4 Years",
    skills: [
      "JavaScript",
      "TypeScript",
      "Node.js",
      "Express",
      "Docker",
      "Redis",
    ],
  });
});

app.listen(8000);
