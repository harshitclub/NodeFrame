const library = {
  fiction: {},
  science: {},
  history: {},
};

library.science["Atomic Habits"] = {};

console.log(library);
